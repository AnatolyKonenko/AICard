/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package durakai;

/**
 *
 * @author Linea
 */
public class CardType { 
    public String Pika="Pika";
    public String Bubna="Bubna";
    public String Cherva="Cherva";
    public String Trefa="Trefa";
    public String Kozir="Kozir";
 }
